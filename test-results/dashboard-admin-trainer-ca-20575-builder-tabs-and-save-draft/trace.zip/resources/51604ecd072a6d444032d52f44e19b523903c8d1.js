
    (() => {
      const tableData = {"profiles":[{"id":"e2e-admin","full_name":"E2E Admin","role":"admin","admin_id":"ADM-001","email":"admin@example.com","is_active":true,"created_at":"2026-03-01T08:00:00.000Z"},{"id":"e2e-trainer","full_name":"E2E Trainer","role":"trainer","admin_id":"TR-002","email":"trainer@example.com","is_active":false,"created_at":"2026-03-02T08:00:00.000Z"},{"id":"e2e-student-1","full_name":"Alpha Student","role":"student","student_id":"ST-001","email":"alpha@example.com","is_active":true,"created_at":"2026-03-03T08:00:00.000Z"},{"id":"e2e-student-2","full_name":"Bravo Student","role":"student","student_id":"ST-002","email":"bravo@example.com","is_active":true,"created_at":"2026-03-04T08:00:00.000Z"}],"payments":[{"id":"pay-1","amount":"120","currency":"AUD","payment_method":"card","status":"completed","paid_at":"2026-03-10T10:00:00.000Z","profiles":{"full_name":"Alpha Student"},"courses":{"title":"Safety 101"}},{"id":"pay-2","amount":"50","currency":"AUD","payment_method":"manual","status":"pending","paid_at":"2026-03-11T10:00:00.000Z","profiles":{"full_name":"Bravo Student"},"courses":{"title":"Rigging Basics"}},{"id":"pay-3","amount":"75","currency":"AUD","payment_method":"card","status":"failed","paid_at":"2026-03-12T10:00:00.000Z","profiles":{"full_name":"Charlie Student"},"courses":{"title":"Care Fundamentals"}}],"schedules":[],"assignment_submissions":[{"id":"sub-1","status":"submitted","submitted_at":"2026-03-10T10:00:00.000Z","grade":null,"profiles":{"id":"e2e-student-1","full_name":"Alpha Student"},"assignments":{"title":"Module 1 Quiz","trainer_id":"e2e-trainer","pass_mark":70},"notes":"Need detailed feedback","file_urls":["https://example.com/assignment.pdf"]},{"id":"sub-2","status":"graded","submitted_at":"2026-03-09T10:00:00.000Z","grade":88,"profiles":{"id":"e2e-student-2","full_name":"Bravo Student"},"assignments":{"title":"Final Quiz","trainer_id":"e2e-trainer","pass_mark":70},"notes":"","file_urls":[]},{"id":"sub-3","status":"resubmit_required","submitted_at":"2026-03-08T10:00:00.000Z","grade":45,"profiles":{"id":"e2e-student-1","full_name":"Alpha Student"},"assignments":{"title":"Case Study","trainer_id":"e2e-trainer","pass_mark":70},"notes":"Resubmit required","file_urls":[]}],"messages":[{"id":"msg-1","subject":"Question","body":"Need help with Module 2.","is_read":false,"created_at":"2026-03-10T08:00:00.000Z","profiles":{"full_name":"Alpha Student","avatar_url":null}},{"id":"msg-2","subject":"Thanks","body":"All good now.","is_read":true,"created_at":"2026-03-09T08:00:00.000Z","profiles":{"full_name":"Bravo Student","avatar_url":null}}],"announcements":[],"certificates":[{"id":"cert-1"},{"id":"cert-2"}],"v_trainer_dashboard":[{"trainer_id":"e2e-trainer","total_students":12,"courses_created":3,"pending_grading":2,"avg_completion_percent":76}],"v_students_at_risk":[],"activity_logs":[],"courses":[{"id":"course-1","title":"Leadership Basics","status":"published","category_id":"communication","thumbnail_url":"","created_at":"2026-03-01T08:00:00.000Z","categories":{"name":"Communication"}},{"id":"course-2","title":"Emergency Response","status":"draft","category_id":"first-aid","thumbnail_url":"","created_at":"2026-03-02T08:00:00.000Z","categories":{"name":"First Aid"}}],"enrollments":[],"forum_posts":[],"notifications":[],"v_course_overview":[]};
      const storedMessages = window.localStorage.getItem("__e2eMessages");
      if (storedMessages) {
        try { tableData.messages = JSON.parse(storedMessages); } catch {}
      }
      const currentUser = {"id":"e2e-trainer","email":"trainer@example.com"};

      const getValue = (obj, path) => {
        if (!obj) return undefined;
        return path.split(".").reduce((acc, key) => (acc ? acc[key] : undefined), obj);
      };

      const makeResponse = (rows) => ({
        data: rows,
        error: null,
        count: Array.isArray(rows) ? rows.length : 0
      });

      const createQuery = (table) => {
        const baseRows = Array.isArray(tableData[table]) ? tableData[table] : [];
        let rows = baseRows.slice();
        let limitValue = null;

        const toComparable = (value) => {
          if (!value) return value;
          const date = new Date(value);
          if (!Number.isNaN(date.getTime())) return date.getTime();
          return value;
        };

        const api = {
          select: () => api,
          eq: (col, val) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return value === val;
            });
            return api;
          },
          in: (col, vals) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return vals.includes(value);
            });
            return api;
          },
          or: () => api,
          order: () => api,
          lt: (col, val) => {
            const target = toComparable(val);
            rows = rows.filter((row) => {
              const value = toComparable(getValue(row, col));
              if (typeof value === "undefined") return true;
              return value < target;
            });
            return api;
          },
          gte: (col, val) => {
            const target = toComparable(val);
            rows = rows.filter((row) => {
              const value = toComparable(getValue(row, col));
              if (typeof value === "undefined") return true;
              return value >= target;
            });
            return api;
          },
          limit: (n) => {
            limitValue = n;
            return api;
          },
          single: () => Promise.resolve({ data: rows[0] || null, error: null }),
          insert: (payload) => {
            const items = Array.isArray(payload) ? payload : [payload];
            items.forEach((item) => {
              if (!item.id) {
                item.id = table + "-e2e-" + Math.random().toString(36).slice(2, 8);
              }
              baseRows.push(item);
            });
            return api;
          },
          update: (payload) => {
            rows.forEach((row) => Object.assign(row, payload));
            return api;
          },
          delete: () => {
            rows.forEach((row) => {
              const idx = baseRows.indexOf(row);
              if (idx >= 0) baseRows.splice(idx, 1);
            });
            return api;
          }
        };

        api.then = (resolve) => {
          const data = limitValue ? rows.slice(0, limitValue) : rows;
          return resolve(makeResponse(data));
        };
        api.catch = (reject) => Promise.resolve(makeResponse(rows)).catch(reject);
        return api;
      };

      window.supabase = {
        createClient: () => ({
          auth: {
            getSession: async () => ({
              data: { session: { user: currentUser } },
              error: null
            }),
            getUser: async () => ({
              data: { user: currentUser },
              error: null
            }),
            signOut: async () => ({ error: null })
          },
          from: (table) => createQuery(table),
          channel: () => ({
            on: () => ({ subscribe: () => ({}) })
          })
        })
      };

      window.__e2eSetMessages = (msgs) => {
        tableData.messages = msgs;
        window.localStorage.setItem("__e2eMessages", JSON.stringify(msgs));
      };
    })();
  