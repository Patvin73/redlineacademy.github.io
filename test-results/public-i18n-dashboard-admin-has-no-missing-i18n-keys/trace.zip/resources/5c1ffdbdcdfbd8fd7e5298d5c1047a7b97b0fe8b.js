
    (() => {
      const tableData = {"profiles":[{"id":"e2e-admin","full_name":"E2E Admin","role":"admin","admin_id":"ADM-001","email":"admin@example.com","is_active":true,"created_at":"2026-03-01T08:00:00.000Z"},{"id":"e2e-trainer","full_name":"E2E Trainer","role":"trainer","admin_id":"TR-002","email":"trainer@example.com","is_active":false,"created_at":"2026-03-02T08:00:00.000Z"}],"payments":[],"schedules":[],"assignment_submissions":[],"messages":[],"announcements":[],"certificates":[],"v_trainer_dashboard":[{"trainer_id":"e2e-admin","total_students":0,"courses_created":0,"pending_grading":0,"avg_completion_percent":0}],"v_students_at_risk":[],"activity_logs":[],"courses":[],"enrollments":[],"forum_posts":[],"notifications":[],"v_course_overview":[]};
      const currentUser = {"id":"e2e-admin","email":"admin@example.com"};

      const getValue = (obj, path) => {
        if (!obj) return undefined;
        return path.split(".").reduce((acc, key) => (acc ? acc[key] : undefined), obj);
      };

      const makeResponse = (rows) => ({
        data: rows,
        error: null,
        count: Array.isArray(rows) ? rows.length : 0
      });

      const createQuery = (table) => {
        const baseRows = Array.isArray(tableData[table]) ? tableData[table] : [];
        let rows = baseRows.slice();
        let limitValue = null;

        const api = {
          select: () => api,
          eq: (col, val) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return value === val;
            });
            return api;
          },
          in: (col, vals) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return vals.includes(value);
            });
            return api;
          },
          or: () => api,
          order: () => api,
          lt: () => api,
          gte: () => api,
          limit: (n) => {
            limitValue = n;
            return api;
          },
          single: () => Promise.resolve({ data: rows[0] || null, error: null }),
          insert: () => api,
          update: () => api,
          delete: () => api
        };

        api.then = (resolve) => {
          const data = limitValue ? rows.slice(0, limitValue) : rows;
          return resolve(makeResponse(data));
        };
        api.catch = (reject) => Promise.resolve(makeResponse(rows)).catch(reject);
        return api;
      };

      window.supabase = {
        createClient: () => ({
          auth: {
            getSession: async () => ({
              data: { session: { user: currentUser } },
              error: null
            }),
            getUser: async () => ({
              data: { user: currentUser },
              error: null
            }),
            signOut: async () => ({ error: null })
          },
          from: (table) => createQuery(table),
          channel: () => ({
            on: () => ({ subscribe: () => ({}) })
          })
        })
      };
    })();
  