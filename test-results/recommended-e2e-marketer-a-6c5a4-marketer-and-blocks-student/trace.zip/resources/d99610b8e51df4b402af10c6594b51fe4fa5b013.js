
    (() => {
      const tableData = {"profiles":[{"id":"marketer-1","full_name":"Marketer One","role":"marketer","email":"marketer@example.com"},{"id":"staff-1","full_name":"Staff One","role":"staff","email":"staff@example.com"},{"id":"student-1","full_name":"Student One","role":"student","student_id":"ST-002","email":"student@example.com"}],"marketer_schools":[{"id":"school-1","marketer_id":"marketer-1","name":"SMK Nusantara","city":"Bandung","contact_name":"Pak Arif","phone":"08123456789","notes":""}],"marketer_claims":[{"id":"claim-1","marketer_id":"marketer-1","school_id":"school-1","ref_id":"DUP-001","presentation_date":"2026-03-01","students_present":12,"students_enrolled":5,"program_fee":5000000,"access_fee":0,"enrollment_comm":2500000,"bonus":500000,"total_commission":3000000,"status":"rejected","notes":"Incomplete docs","marketer_schools":{"name":"SMK Nusantara","city":"Bandung"}},{"id":"claim-2","marketer_id":"marketer-1","school_id":"school-1","ref_id":"DUP-001","presentation_date":"2026-03-05","students_present":8,"students_enrolled":3,"program_fee":4000000,"access_fee":0,"enrollment_comm":1200000,"bonus":0,"total_commission":1200000,"status":"pending","notes":"","marketer_schools":{"name":"SMK Nusantara","city":"Bandung"}}]};
      const currentUser = {"id":"student-1","email":"student@example.com"};

      const getValue = (obj, path) => {
        if (!obj) return undefined;
        return path.split(".").reduce((acc, key) => (acc ? acc[key] : undefined), obj);
      };

      const makeResponse = (rows) => ({
        data: rows,
        error: null,
        count: Array.isArray(rows) ? rows.length : 0
      });

      const toComparable = (value) => {
        if (!value) return value;
        const date = new Date(value);
        if (!Number.isNaN(date.getTime())) return date.getTime();
        return value;
      };

      const createQuery = (table) => {
        const baseRows = Array.isArray(tableData[table]) ? tableData[table] : [];
        let rows = baseRows.slice();
        let limitValue = null;

        const api = {
          select: () => api,
          eq: (col, val) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return value === val;
            });
            return api;
          },
          in: (col, vals) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return vals.includes(value);
            });
            return api;
          },
          or: () => api,
          order: () => api,
          lt: (col, val) => {
            const target = toComparable(val);
            rows = rows.filter((row) => {
              const value = toComparable(getValue(row, col));
              if (typeof value === "undefined") return true;
              return value < target;
            });
            return api;
          },
          gte: (col, val) => {
            const target = toComparable(val);
            rows = rows.filter((row) => {
              const value = toComparable(getValue(row, col));
              if (typeof value === "undefined") return true;
              return value >= target;
            });
            return api;
          },
          limit: (n) => {
            limitValue = n;
            return api;
          },
          single: () => Promise.resolve({ data: rows[0] || null, error: null }),
          insert: (payload) => {
            const items = Array.isArray(payload) ? payload : [payload];
            items.forEach((item) => {
              if (!item.id) {
                item.id = table + "-e2e-" + Math.random().toString(36).slice(2, 8);
              }
              baseRows.push(item);
            });
            return api;
          },
          update: (payload) => {
            rows.forEach((row) => Object.assign(row, payload));
            return api;
          },
          delete: () => {
            rows.forEach((row) => {
              const idx = baseRows.indexOf(row);
              if (idx >= 0) baseRows.splice(idx, 1);
            });
            return api;
          }
        };

        api.then = (resolve) => {
          const data = limitValue ? rows.slice(0, limitValue) : rows;
          return resolve(makeResponse(data));
        };
        api.catch = (reject) => Promise.resolve(makeResponse(rows)).catch(reject);
        return api;
      };

      window.supabase = {
        createClient: () => ({
          auth: {
            getSession: async () => ({
              data: { session: { user: currentUser } },
              error: null
            }),
            getUser: async () => ({
              data: { user: currentUser },
              error: null
            }),
            signOut: async () => ({ error: null })
          },
          from: (table) => createQuery(table),
          channel: () => ({
            on: () => ({ subscribe: () => ({}) })
          }),
          storage: {
            from: () => ({
              upload: async () => ({ error: null }),
              getPublicUrl: () => ({ data: { publicUrl: "" } })
            })
          }
        })
      };
    })();
  