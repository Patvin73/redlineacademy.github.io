
    (() => {
      const tableData = {"profiles":[{"id":"student-1","full_name":"Alpha Student","role":"student","student_id":"ST-001","email":"alpha@example.com","created_at":"2026-03-02T08:00:00.000Z"},{"id":"admin-1","full_name":"Admin User","role":"admin","admin_id":"ADM-001","email":"admin@example.com","created_at":"2026-03-01T08:00:00.000Z"}],"v_student_dashboard":[{"student_id":"student-1","courses_enrolled":2,"lessons_completed":8,"pending_submissions":1,"certificates_earned":0}],"course_progress":[{"student_id":"student-1","completion_percent":65,"last_accessed_at":"2026-03-12T08:00:00.000Z","last_lesson_id":"lesson-1","courses":{"id":"course-1","title":"Caregiver Basics","thumbnail_url":"","slug":"caregiver-basics"},"enrollments":{"status":"active"}}],"enrollments":[{"id":"enroll-1","student_id":"student-1","course_id":"course-1","status":"active","progress_percent":65},{"id":"enroll-2","student_id":"student-1","course_id":"course-2","status":"completed","progress_percent":100}],"courses":[{"id":"course-1","title":"Caregiver Basics","thumbnail_url":"","category":"Caregiving","trainer_name":"Trainer One"},{"id":"course-2","title":"Clinical Skills","thumbnail_url":"","category":"Healthcare","trainer_name":"Trainer Two"}],"assignments":[{"id":"assign-1","student_id":"student-1","title":"Module 1 Quiz","type":"quiz","course_title":"Caregiver Basics","due_at":"2026-03-20"},{"id":"assign-2","student_id":"student-1","title":"Final Assignment","type":"assignment","course_title":"Clinical Skills","due_at":"2026-03-25"}],"assignment_submissions":[{"id":"sub-1","assignment_id":"assign-2","student_id":"student-1","status":"graded","submitted_at":"2026-03-10T08:00:00.000Z"}],"schedules":[{"id":"sched-1","course_id":"course-1","title":"Live Session","event_type":"live_session","start_datetime":"2099-01-01T10:00:00.000Z","end_datetime":"2099-01-01T11:00:00.000Z","meeting_url":"https://example.com/meet"}],"activity_logs":[],"notifications":[],"messages":[]};
      const currentUser = {"id":"student-1","email":"alpha@example.com"};

      const getValue = (obj, path) => {
        if (!obj) return undefined;
        return path.split(".").reduce((acc, key) => (acc ? acc[key] : undefined), obj);
      };

      const makeResponse = (rows) => ({
        data: rows,
        error: null,
        count: Array.isArray(rows) ? rows.length : 0
      });

      const toComparable = (value) => {
        if (!value) return value;
        const date = new Date(value);
        if (!Number.isNaN(date.getTime())) return date.getTime();
        return value;
      };

      const createQuery = (table) => {
        const baseRows = Array.isArray(tableData[table]) ? tableData[table] : [];
        let rows = baseRows.slice();
        let limitValue = null;

        const api = {
          select: () => api,
          eq: (col, val) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return value === val;
            });
            return api;
          },
          in: (col, vals) => {
            rows = rows.filter((row) => {
              const value = getValue(row, col);
              if (typeof value === "undefined") return true;
              return vals.includes(value);
            });
            return api;
          },
          or: () => api,
          order: () => api,
          lt: (col, val) => {
            const target = toComparable(val);
            rows = rows.filter((row) => {
              const value = toComparable(getValue(row, col));
              if (typeof value === "undefined") return true;
              return value < target;
            });
            return api;
          },
          gte: (col, val) => {
            const target = toComparable(val);
            rows = rows.filter((row) => {
              const value = toComparable(getValue(row, col));
              if (typeof value === "undefined") return true;
              return value >= target;
            });
            return api;
          },
          limit: (n) => {
            limitValue = n;
            return api;
          },
          single: () => Promise.resolve({ data: rows[0] || null, error: null }),
          insert: (payload) => {
            const items = Array.isArray(payload) ? payload : [payload];
            items.forEach((item) => {
              if (!item.id) {
                item.id = table + "-e2e-" + Math.random().toString(36).slice(2, 8);
              }
              baseRows.push(item);
            });
            return api;
          },
          update: (payload) => {
            rows.forEach((row) => Object.assign(row, payload));
            return api;
          },
          delete: () => {
            rows.forEach((row) => {
              const idx = baseRows.indexOf(row);
              if (idx >= 0) baseRows.splice(idx, 1);
            });
            return api;
          }
        };

        api.then = (resolve) => {
          const data = limitValue ? rows.slice(0, limitValue) : rows;
          return resolve(makeResponse(data));
        };
        api.catch = (reject) => Promise.resolve(makeResponse(rows)).catch(reject);
        return api;
      };

      window.supabase = {
        createClient: () => ({
          auth: {
            getSession: async () => ({
              data: { session: { user: currentUser } },
              error: null
            }),
            getUser: async () => ({
              data: { user: currentUser },
              error: null
            }),
            signOut: async () => ({ error: null })
          },
          from: (table) => createQuery(table),
          channel: () => ({
            on: () => ({ subscribe: () => ({}) })
          }),
          storage: {
            from: () => ({
              upload: async () => ({ error: null }),
              getPublicUrl: () => ({ data: { publicUrl: "" } })
            })
          }
        })
      };
    })();
  